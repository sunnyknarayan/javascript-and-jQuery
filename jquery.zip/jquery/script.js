
///////////// original code ////////////

jQuery(document).ready(function()
{
  if(!localStorage.student)
  {
  jQuery.ajax({
    "type" : "GET",
     url:'data.json',
    "success" : function(data)
    {
       var data_arr = JSON.stringify(data);
      localStorage.setItem("student",data_arr);
      draw_table(10);
      drag_drop();
    }
  });
  }
  else{
  draw_table(10);
  drag_drop();
}
});
var id;
var arr_loc = [];

//////// save function ////

function validate()
{
 
  var elem_obj = $('[ma_validate="true"]');
  err_elem_obj = $('[actn="err"]');
  
  if(err_elem_obj.length > 0)
  {
    for(var j=0;j<err_elem_obj.length;j++){
      err_elem_obj[j].remove();
    }
  }
  
  for(var i=0;i<elem_obj.length;i++){
    if(elem_obj[i].value === ''){
var err_html = '<p actn="err">please fill '+$(elem_obj[i]).attr('placeholder')+'</p>';
$(err_html).insertAfter(elem_obj[i]);
    }
    
  }
  save();
  return false;
}
function save(){
     
        var firstname = $("#fname").val();
        var lastname = $("#lname").val();
        var email = $("#email").val();
        var phone = $("#phone").val();
        var current_class = $("#curr_class").val();
        var location = arr_loc;
         
        if(location.length===0)
        {
          $("<p>please fill the location</p>").insertAfter("#cartid");
        }
        var address = {
          communication : $("#communication").val(),
          permanent : $("#perm").val()
        }
        //console.log(address);
        var marks = {
         english : $("#english").val(),
         science : $("#science").val(),
         computers : $("#computers").val(),
         hardware : $("#hardware").val()
        }
        
  if(firstname!=="" && lastname!=="" && email!=="" && phone!=="" && current_class!=="" && location!==""
  && address.communication!=="" && address.permanent!=="" && marks.english!==""
  && marks.science!=="" && marks.computers!=="" && marks.hardware!=="")
  {
  var obj = new createStudent(firstname,lastname,email,phone,current_class,location,address,marks);

var key = localStorage.key("student");
var details = localStorage.getItem(key);
var details_obj = JSON.parse(details);
console.log(details_obj.length);
details_obj.unshift(obj);
console.log(details_obj.length);
details_json = JSON.stringify(details_obj);
localStorage.setItem("student",details_json);
draw_table(10);
  }
  
}

//// object constructor //////
function createStudent(firstname1,lastname1,email1,phone1,current_class1,location1,address1,marks1)
         {
              this.firstname = firstname1;
              this.lastname = lastname1;
              this.email = email1;
              this.location = location1;
              this.phone = phone1;
              this.current_class = current_class1;
              this.address = address1;
              this.marks = marks1;
         }
         
  
///////// table creation /////////
  function draw_table(value){
      data_arr = localStorage.getItem("student");
     var arr = JSON.parse(data_arr);
      var html = "<table border='1'>";
      html +="<tr> <th> Firstname </th> <th> Lastname </th> <th> Email </th> <th> Location </th><th> Phone </th><th> Current_class </th> <th> Address </th><th> Marks </th><th> Operations </th>";
      for(var i=0;i<value;i++){
       html += "<tr><td>"+arr[i].firstname +"</td>";
       html +="<td>"+ arr[i].lastname +"</td>";
       html +="<td>"+ arr[i].email+"</td>";
       html +="<td>"+ arr[i].location +"</td>";
       html +="<td>"+ arr[i].phone +"</td>";
       html +="<td>"+ arr[i].current_class +"</td>";
       html +="<td>"+ arr[i].address.communication+","+arr[i].address.permanent +"</td>";
       html +="<td>"+ arr[i].marks.english+","+arr[i].marks.science +","+arr[i].marks.computers+","+arr[i].marks.hardware+"</td>";
       html +="<td><a href='#' id='actn_view_"+i+"'>View</a> <a href='#' id='actn_edit_"+i+"'>Edit</a> <a href='#' id='actn_save_"+i+"'>Save</a> <a href='#' id='actn_delete_"+i+"'>Delete</a> </td> </tr>";
     }
    html +="</table>";
     document.getElementById("table").innerHTML = html;
}


///search jquery ////

jQuery(document).ready(function()
{
function removeHighlighting(highlightedElements){
    highlightedElements.each(function(){
        var element = $(this);
        element.replaceWith(element.html());
    })
}

function addHighlighting(element, textToHighlight){
    var text = element.text();
    var highlightedText = '<em>' + textToHighlight + '</em>';
    var newText = text.replace(textToHighlight, highlightedText);
    
    element.html(newText);
}

$("#search").on("keyup", function() {
    var value = $(this).val();
    
    removeHighlighting($("table tr em"));

    $("table tr").each(function(index) {
        if (index !== 0) {
            $row = $(this);
            
            var $tdElement = $row.find("td:first-child");
            var id = $tdElement.text();
            var matchedIndex = id.indexOf(value);
            
            if (matchedIndex !== 0) {
                $row.hide();
            }
            else {
                addHighlighting($tdElement, value);
                $row.show();
            }
        }
    });
});
});

/////////// drag and drop ///////////
function drag_drop()
      {
        jQuery(".source li").draggable({helper:"clone"});
        jQuery("#cartid").droppable({drop:function(event, ui)
          {
            jQuery("#items").append($("<li></li>").text(ui.draggable.text()));
            id = ui.draggable.attr("id");
            arr_loc.push(id);
            console.log(arr_loc);
          }
          
        });
      }

////////// drop down ///////
$(document).ready(function(){
     $("#optid").change(function(){
      var x = document.getElementById("optid").value;
      console.log(x);
      draw_table(x);
     });
   });

////////// view, edit, save,delete /////////
jQuery(document).on('click', '[id^="actn_"]', function(e) {
  e.preventDefault();
  var this_obj = jQuery(this),
      idSplit = this_obj.attr('id').split('_'),
      actn = idSplit[1];
      console.log(actn);
      switch(actn) {
       case 'view':
          view_details(this_obj);
          //console.log("view clicked");
        break;
        case 'edit':
          edit_details(this_obj);
        break;
        case 'delete':
          console.log("delete clicked");
          delete_details(this_obj);
        break;
        case 'save':
          console.log("save clicked");
          save_details(this_obj);
        break;
      }
});
function view_details(this_obj) {
  var id = 'details_'+this_obj.attr('id'),
  user_data = localStorage.getItem('student'),

  idSplit = this_obj.attr('id').split('_');

  user_data = JSON.parse(user_data);

  user_data = user_data[idSplit[2]];
  console.log(user_data);
  var details_htm="<h4>"+
  "<p>"+"English : "+user_data.marks.english+', '+"<br/>"+
  "<p>"+"Science : "+user_data.marks.science+', '+"<br/>"+
  "<p>"+"Computers : "+user_data.marks.computers+', '+"<br/>"+
  "<p>"+"Hardware : "+user_data.marks.hardware;
    htm = '<tr id="'+id+'"><td colspan="5">'+details_htm+'</td><tr>';
 //console.log(user_data);
  if(this_obj.attr('st')) {
    if(this_obj.attr('st')=='open') {
      jQuery('tr[id="'+id+'"]').hide();
      this_obj.attr('st', 'close');
    } else {
      jQuery('tr[id="'+id+'"]').show();
    }
  } else {
    this_obj.attr('st', 'open');
    this_obj.parent().parent().after(htm);
  }
}

function edit_details(this_obj){
  //console.log(this_obj);
 var par = $(this_obj).parent().parent(); //tr 
 //console.log(par);
 var firstname = par.children("td:nth-child(1)");
 var lastname = par.children("td:nth-child(2)");
 var email = par.children("td:nth-child(3)");
 var location = par.children("td:nth-child(4)");
 var phone = par.children("td:nth-child(5)");
 var current_class = par.children("td:nth-child(6)");
 var address = par.children("td:nth-child(7)");
 var marks = par.children("td:nth-child(8)");
 //console.log(address.html());
firstname.html("<input type='text' id='fname1' value='"+firstname.html()+"'/>");
lastname.html("<input type='text' id='lname1' value='"+lastname.html()+"'/>");
email.html("<input type='text' id='email1' value='"+email.html()+"'/>");
location.html("<input type='text' id='location1' value='"+location.html()+"'/>");
//console.log(phone.html());
phone.html("<input type='text' id='phone1' value='"+phone.html()+"'/>");
current_class.html("<input type='text' id='curr_class1' value='"+current_class.html()+"'/>");
console.log(address.html());
address.html("<input type='text' id='address1' value='"+address.html()+"'/>");
marks.html("<input type='text' id='marks1' value='"+marks.html()+"'/>");

  
}

function save_details(this_obj){
  var par = $(this_obj).parent().parent(); //tr 
var idSplit = this_obj.attr('id').split('_');
var key = localStorage.key("student");
var details = localStorage.getItem(key);
var details_obj = JSON.parse(details);

user_data = details_obj[idSplit[2]];
var i = idSplit[2];
 console.log(details_obj[i]);
////first name ////
var firstname = par.children("td:nth-child(1)");
details_obj[i].firstname = firstname.children("input[id=fname1]").val();
firstname.html(firstname.children("input[type=text]").val());
 
////last name////
var lastname = par.children("td:nth-child(2)");
details_obj[i].lastname = lastname.children("input[id=lname1]").val();
lastname.html(lastname.children("input[type=text]").val());
 
////email////
var email = par.children("td:nth-child(3)");
details_obj[i].email = email.children("input[id=email1]").val();
email.html(email.children("input[type=text]").val());
 
//// location ////
var location = par.children("td:nth-child(4)");
details_obj[i].location = location.children("input[id=location1]").val();
location.html(location.children("input[type=text]").val());

////phone////
var phone = par.children("td:nth-child(5)");
details_obj[i].phone = phone.children("input[id=phone1]").val();
phone.html(phone.children("input[type=text]").val());
 
////current class////
var current_class = par.children("td:nth-child(6)");
details_obj[i].current_class = current_class.children("input[id=curr_class1]").val();
current_class.html(current_class.children("input[type=text]").val());
 
//// address ////
var address = par.children("td:nth-child(7)");
details_obj[i].address= address.children("input[id=address1]").val();
var sp_addr = details_obj[i].address.split(',');
details_obj[i].address = {
  "communication":sp_addr[0],
  "permanent":sp_addr[1]
}
address.html(address.children("input[type=text]").val());

 //// marks ////
var marks = par.children("td:nth-child(8)");
details_obj[i].marks = marks.children("input[id=marks1]").val();
var sp_marks = details_obj[i].marks.split(',');
details_obj[i].marks = {
  "english":sp_marks[0],
  "science":sp_marks[1],
  "computers":sp_marks[2],
  "hardware":sp_marks[3]
}
marks.html(marks.children("input[type=text]").val());


var data_arr = JSON.stringify(details_obj);
//console.log(data_arr);
localStorage.setItem("student",data_arr);
}

function delete_details(this_obj) {
  //console.log(this_obj);
  this_obj.parent().parent().remove();

  user_data = localStorage.getItem('student'),
  idSplit = this_obj.attr('id').split('_');
  //console.log(idSplit[2]);

var key = localStorage.key("student");
var details = localStorage.getItem(key);
var parsed_array_obj = JSON.parse(details);
parsed_array_obj.splice(idSplit[2],1);
localStorage.setItem("student", JSON.stringify(parsed_array_obj));
}
///// scroll ///////
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
